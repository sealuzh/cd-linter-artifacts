/**
 * 
 */
/**
 *
 *
 */
package cdlinter.datamining.gitlab.entities;