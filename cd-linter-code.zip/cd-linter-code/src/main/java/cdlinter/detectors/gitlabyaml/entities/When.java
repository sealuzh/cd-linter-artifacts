package cdlinter.detectors.gitlabyaml.entities;

public enum When
{
    always,
    on_success,
    on_failure,
    manual,
    delayed
    ;
}
